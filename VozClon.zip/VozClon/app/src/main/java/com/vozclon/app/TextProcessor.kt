package com.vozclon.app

import java.text.Normalizer
import java.util.Locale

/**
 * Prepara el texto: normaliza acentos (NFC), respeta la puntuación tal cual,
 * convierte párrafos y puntos suspensivos en pausas <break/> y divide el texto
 * en fragmentos sin cortar frases a la mitad.
 */
object TextProcessor {
    private const val MAX_CHARS = 2000
    private val sentenceSplit = Regex("(?<=[.!?…])\\s+")
    private val breakTag = Regex("<break[^>]*/>")

    private data class Piece(val text: String, val endsParagraph: Boolean)

    private fun tag(seconds: Float) =
        "<break time=\"${String.format(Locale.US, "%.1f", seconds)}s\" />"

    fun chunks(raw: String, autoPauses: Boolean, paragraphPause: Float): List<String> {
        val clean = Normalizer.normalize(raw.replace("\r\n", "\n"), Normalizer.Form.NFC)
            .replace(Regex("[ \\t]+"), " ")
            .trim()

        val paragraphs = clean.split(Regex("\\n\\s*\\n"))
            .map { it.replace(Regex("\\s*\\n\\s*"), " ").trim() }
            .filter { it.isNotEmpty() }

        val pieces = mutableListOf<Piece>()
        for (p0 in paragraphs) {
            val p = if (autoPauses) {
                p0.replace(Regex("\\s*(\\.\\.\\.|…)\\s*"), " ${tag(0.6f)} ")
            } else p0

            if (p.length <= MAX_CHARS) {
                pieces += Piece(p, true)
            } else {
                val sb = StringBuilder()
                for (s in p.split(sentenceSplit)) {
                    if (sb.isNotEmpty() && sb.length + s.length + 1 > MAX_CHARS) {
                        pieces += Piece(sb.toString(), false)
                        sb.clear()
                    }
                    if (sb.isNotEmpty()) sb.append(' ')
                    sb.append(s)
                }
                if (sb.isNotEmpty()) pieces += Piece(sb.toString(), true)
            }
        }

        val chunks = mutableListOf<String>()
        val cur = StringBuilder()
        var lastEnds = false

        fun flush(isLast: Boolean) {
            if (cur.isEmpty()) return
            if (!isLast && autoPauses && lastEnds) cur.append(' ').append(tag(paragraphPause))
            chunks += cur.toString()
            cur.clear()
        }

        for (piece in pieces) {
            if (cur.isNotEmpty() && cur.length + piece.text.length > MAX_CHARS) flush(false)
            if (cur.isNotEmpty()) {
                cur.append(
                    when {
                        !lastEnds -> " "
                        autoPauses -> " ${tag(paragraphPause)} "
                        else -> "\n\n"
                    }
                )
            }
            cur.append(piece.text)
            lastEnds = piece.endsParagraph
        }
        flush(true)
        return chunks
    }

    /** Texto limpio de etiquetas, usado como contexto (previous_text / next_text). */
    fun context(chunk: String, tail: Boolean): String {
        val t = chunk.replace(breakTag, " ").replace(Regex("\\s+"), " ").trim()
        return if (tail) t.takeLast(400) else t.take(400)
    }
}

package com.vozclon.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { VozApp(vm) }
            }
        }
    }
}

@Composable
fun VozApp(vm: MainViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("VozClon", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { vm.toggleSettings() }) { Text("Ajustes") }
        }

        if (ui.showSettings) {
            SettingsPanel(ui.settings, onSave = { vm.saveSettings(it) })
        }

        OutlinedTextField(
            value = ui.text,
            onValueChange = { vm.setText(it) },
            label = { Text("Texto a convertir en voz") },
            minLines = 8,
            modifier = Modifier.fillMaxWidth()
        )
        Text("${ui.text.length} caracteres", style = MaterialTheme.typography.bodySmall)

        if (ui.loading) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                androidx.compose.material3.CircularProgressIndicator(Modifier.padding(4.dp))
                Text(ui.progress, Modifier.weight(1f))
                OutlinedButton(onClick = { vm.cancel() }) { Text("Cancelar") }
            }
        } else {
            Button(onClick = { vm.generate() }, modifier = Modifier.fillMaxWidth()) {
                Text("Generar voz")
            }
        }

        ui.message?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        val file = ui.audioFile
        if (file != null) {
            PlayerCard(
                vm = vm,
                isPlaying = ui.isPlaying,
                onShare = {
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "audio/mpeg"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(send, "Compartir audio"))
                }
            )
        }
    }
}

@Composable
fun PlayerCard(vm: MainViewModel, isPlaying: Boolean, onShare: () -> Unit) {
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }

    LaunchedEffect(isPlaying) {
        pos = vm.player.currentPosition
        dur = vm.player.duration.coerceAtLeast(0L)
        while (isPlaying) {
            pos = vm.player.currentPosition
            dur = vm.player.duration.coerceAtLeast(0L)
            delay(300)
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val fraction = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
            Slider(
                value = fraction,
                onValueChange = { vm.seekTo(it); pos = (dur * it).toLong() }
            )
            Text("${fmt(pos)} / ${fmt(dur)}", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.togglePlay() }) { Text(if (isPlaying) "Pausa" else "Reproducir") }
                OutlinedButton(onClick = { vm.saveToDevice() }) { Text("Guardar") }
                OutlinedButton(onClick = onShare) { Text("Compartir") }
            }
        }
    }
}

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun SettingsPanel(initial: VoiceSettings, onSave: (VoiceSettings) -> Unit) {
    var s by remember(initial) { mutableStateOf(initial) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Ajustes", style = MaterialTheme.typography.titleMedium)

            OutlinedTextField(
                value = s.apiKey,
                onValueChange = { s = s.copy(apiKey = it) },
                label = { Text("API key de ElevenLabs") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = s.voiceId,
                onValueChange = { s = s.copy(voiceId = it) },
                label = { Text("Voice ID de tu voz") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = s.modelId,
                onValueChange = { s = s.copy(modelId = it) },
                label = { Text("Modelo") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = s.languageCode,
                onValueChange = { s = s.copy(languageCode = it) },
                label = { Text("Idioma (opcional, p. ej. es)") },
                supportingText = { Text("Déjalo vacío con eleven_multilingual_v2") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            LabeledSlider("Estabilidad", s.stability, 0f..1f) { s = s.copy(stability = it) }
            LabeledSlider("Similitud", s.similarity, 0f..1f) { s = s.copy(similarity = it) }
            LabeledSlider("Estilo", s.style, 0f..1f) { s = s.copy(style = it) }
            LabeledSlider("Velocidad", s.speed, 0.7f..1.2f) { s = s.copy(speed = it) }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = s.autoPauses, onCheckedChange = { s = s.copy(autoPauses = it) })
                Text("Pausas automáticas (párrafos y «…»)", Modifier.weight(1f))
            }
            if (s.autoPauses) {
                LabeledSlider("Pausa entre párrafos (s)", s.paragraphPause, 0.3f..2.0f) {
                    s = s.copy(paragraphPause = it)
                }
            }

            Button(onClick = { onSave(s) }, modifier = Modifier.fillMaxWidth()) {
                Text("Guardar ajustes")
            }
        }
    }
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        Text("$label: ${"%.2f".format(value)}", style = MaterialTheme.typography.bodyMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

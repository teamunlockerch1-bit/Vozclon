package com.vozclon.app

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

data class UiState(
    val settings: VoiceSettings = VoiceSettings(),
    val text: String = "",
    val loading: Boolean = false,
    val progress: String = "",
    val audioFile: File? = null,
    val isPlaying: Boolean = false,
    val message: String? = null,
    val showSettings: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val client = ElevenLabsClient()
    val player: ExoPlayer = ExoPlayer.Builder(app).build()

    private val initial = store.load()
    private val _ui = MutableStateFlow(
        UiState(settings = initial, showSettings = initial.apiKey.isBlank() || initial.voiceId.isBlank())
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var job: Job? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _ui.update { it.copy(isPlaying = isPlaying) }
            }
        })
    }

    fun setText(t: String) = _ui.update { it.copy(text = t) }
    fun toggleSettings() = _ui.update { it.copy(showSettings = !it.showSettings) }

    fun saveSettings(s: VoiceSettings) {
        store.save(s)
        _ui.update { it.copy(settings = s, showSettings = false, message = null) }
    }

    fun generate() {
        val s = _ui.value.settings
        val text = _ui.value.text
        if (s.apiKey.isBlank() || s.voiceId.isBlank()) {
            _ui.update { it.copy(showSettings = true, message = "Configura tu API key y tu Voice ID.") }
            return
        }
        if (text.isBlank()) {
            _ui.update { it.copy(message = "Escribe o pega un texto.") }
            return
        }
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(loading = true, message = null, progress = "Preparando…") }
            try {
                val file = withContext(Dispatchers.IO) { buildAudio(s, text) }
                player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                player.prepare()
                player.play()
                _ui.update { it.copy(audioFile = file) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(message = e.message ?: "Error desconocido") }
            } finally {
                _ui.update { it.copy(loading = false) }
            }
        }
    }

    fun cancel() {
        job?.cancel()
        _ui.update { it.copy(loading = false, message = "Cancelado.") }
    }

    private suspend fun buildAudio(s: VoiceSettings, text: String): File {
        val dir = File(getApplication<Application>().cacheDir, "audio").apply { mkdirs() }
        val key = sha256(
            listOf(
                text, s.voiceId, s.modelId, s.languageCode, s.stability, s.similarity,
                s.style, s.speed, s.autoPauses, s.paragraphPause
            ).joinToString("|")
        )
        val out = File(dir, "$key.mp3")
        if (out.exists() && out.length() > 0) return out // caché: no gasta créditos

        val chunks = TextProcessor.chunks(text, s.autoPauses, s.paragraphPause)
        val tmp = File(dir, "$key.part")
        try {
            tmp.outputStream().use { os ->
                chunks.forEachIndexed { i, chunk ->
                    _ui.update { it.copy(progress = "Generando ${i + 1} de ${chunks.size}…") }
                    val prev = chunks.getOrNull(i - 1)?.let { TextProcessor.context(it, tail = true) }
                    val next = chunks.getOrNull(i + 1)?.let { TextProcessor.context(it, tail = false) }
                    os.write(client.synthesize(s, chunk, prev, next))
                }
            }
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        }
        tmp.renameTo(out)
        return out
    }

    fun togglePlay() {
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
        }
    }

    fun seekTo(fraction: Float) {
        val d = player.duration
        if (d > 0) player.seekTo((d * fraction).toLong())
    }

    fun saveToDevice() {
        val file = _ui.value.audioFile ?: return
        try {
            val resolver = getApplication<Application>().contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, "voz_${System.currentTimeMillis()}.mp3")
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/VozClon")
            }
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("No se pudo crear el archivo")
            resolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
            _ui.update { it.copy(message = "Guardado en Música/VozClon") }
        } catch (e: Exception) {
            _ui.update { it.copy(message = "No se pudo guardar: ${e.message}") }
        }
    }

    private fun sha256(s: String) =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(32)

    override fun onCleared() {
        player.release()
        super.onCleared()
    }
}

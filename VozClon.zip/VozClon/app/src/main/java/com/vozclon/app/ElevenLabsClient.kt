package com.vozclon.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ElevenLabsClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    private fun r2(x: Float) = Math.round(x * 100) / 100.0

    suspend fun synthesize(
        s: VoiceSettings,
        text: String,
        previousText: String?,
        nextText: String?
    ): ByteArray = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("text", text)
            put("model_id", s.modelId)
            // Solo algunos modelos (turbo/flash v2.5, v3) aceptan language_code.
            if (s.languageCode.isNotBlank()) put("language_code", s.languageCode.trim())
            put("voice_settings", JSONObject().apply {
                put("stability", r2(s.stability))
                put("similarity_boost", r2(s.similarity))
                put("style", r2(s.style))
                put("speed", r2(s.speed))
                put("use_speaker_boost", true)
            })
            if (!previousText.isNullOrBlank()) put("previous_text", previousText)
            if (!nextText.isNullOrBlank()) put("next_text", nextText)
        }

        val request = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-speech/${s.voiceId.trim()}?output_format=mp3_44100_128")
            .header("xi-api-key", s.apiKey.trim())
            .header("Accept", "audio/mpeg")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException(parseError(resp.code, resp.body?.string()))
            resp.body?.bytes() ?: throw IOException("Respuesta vacía del servidor")
        }
    }

    private fun parseError(code: Int, body: String?): String {
        val detail: String = try {
            val d = JSONObject(body ?: "").opt("detail")
            when (d) {
                is JSONObject -> d.optString("message", d.toString())
                is String -> d
                else -> body ?: ""
            }
        } catch (e: Exception) {
            body ?: ""
        }
        return when (code) {
            401 -> "API key inválida o sin permisos (401). $detail"
            404 -> "Voice ID no encontrado (404). $detail"
            422 -> "Parámetros inválidos (422). $detail"
            429 -> "Límite de uso alcanzado (429). $detail"
            else -> "Error $code. $detail"
        }
    }
}

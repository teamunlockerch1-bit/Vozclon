package com.vozclon.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

data class VoiceSettings(
    val apiKey: String = "",
    val voiceId: String = "",
    val modelId: String = "eleven_multilingual_v2",
    val languageCode: String = "",
    val stability: Float = 0.45f,
    val similarity: Float = 0.75f,
    val style: Float = 0.1f,
    val speed: Float = 1.0f,
    val autoPauses: Boolean = true,
    val paragraphPause: Float = 0.8f
)

/** Guarda los ajustes (incluida la API key) cifrados en el teléfono. */
class SettingsStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "voz_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun load(): VoiceSettings {
        val d = VoiceSettings()
        return VoiceSettings(
            apiKey = prefs.getString("apiKey", "") ?: "",
            voiceId = prefs.getString("voiceId", "") ?: "",
            modelId = prefs.getString("modelId", d.modelId) ?: d.modelId,
            languageCode = prefs.getString("languageCode", "") ?: "",
            stability = prefs.getFloat("stability", d.stability),
            similarity = prefs.getFloat("similarity", d.similarity),
            style = prefs.getFloat("style", d.style),
            speed = prefs.getFloat("speed", d.speed),
            autoPauses = prefs.getBoolean("autoPauses", d.autoPauses),
            paragraphPause = prefs.getFloat("paragraphPause", d.paragraphPause)
        )
    }

    fun save(s: VoiceSettings) {
        prefs.edit()
            .putString("apiKey", s.apiKey.trim())
            .putString("voiceId", s.voiceId.trim())
            .putString("modelId", s.modelId.trim())
            .putString("languageCode", s.languageCode.trim())
            .putFloat("stability", s.stability)
            .putFloat("similarity", s.similarity)
            .putFloat("style", s.style)
            .putFloat("speed", s.speed)
            .putBoolean("autoPauses", s.autoPauses)
            .putFloat("paragraphPause", s.paragraphPause)
            .apply()
    }
}

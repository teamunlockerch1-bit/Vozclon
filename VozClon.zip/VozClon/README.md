# VozClon
App Android (Kotlin + Jetpack Compose) de texto a voz con tu voz de ElevenLabs.

1. Abre esta carpeta con Android Studio y espera a que termine "Gradle Sync".
2. Conecta tu móvil (Depuración USB) y pulsa Run, o usa Build > Build APK(s).
3. En la app: Ajustes > pega tu API key y tu Voice ID.
